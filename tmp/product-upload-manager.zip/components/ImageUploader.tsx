import React, { useState, useCallback, useEffect } from 'react';
import { ManagedFile, UploadStatus } from '../types';
import ImagePreviewCard from './ImagePreviewCard';
import { UploadCloudIcon, CheckCircleIcon, SuccessIllustrationIcon } from './Icons';

const MAX_FILES = 10;

const ImageUploader: React.FC = () => {
  const [files, setFiles] = useState<ManagedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const addFiles = useCallback((newFiles: File[]) => {
    setFiles(prev => {
      const availableSlots = MAX_FILES - prev.length;
      if (availableSlots <= 0) return prev;

      const filesToAdd = newFiles.slice(0, availableSlots);

      const managedFiles: ManagedFile[] = filesToAdd
        .filter(file => file.type.startsWith('image/'))
        .map(file => ({
          id: `${file.name}-${file.lastModified}-${Math.random()}`,
          file,
          previewUrl: URL.createObjectURL(file),
          status: UploadStatus.Waiting,
          progress: 0,
        }));
      return [...prev, ...managedFiles];
    });
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      addFiles(Array.from(e.target.files));
    }
    e.target.value = ''; // Allow re-selecting the same file
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      addFiles(Array.from(e.dataTransfer.files));
      e.dataTransfer.clearData();
    }
  };

  const removeFile = useCallback((id: string) => {
    setFiles(prev => {
        const fileToRemove = prev.find(f => f.id === id);
        if (fileToRemove) {
            URL.revokeObjectURL(fileToRemove.previewUrl);
        }
        return prev.filter(f => f.id !== id);
    });
  }, []);
  
  const simulateUpload = (fileId: string) => {
    return new Promise<void>((resolve, reject) => {
      const interval = setInterval(() => {
        setFiles(prev => prev.map(f => {
          if (f.id === fileId && f.status === UploadStatus.Uploading) {
            const newProgress = Math.min(f.progress + 10, 100);
            if (newProgress === 100) {
              clearInterval(interval);
              // Simulate a random success/error outcome
              if (Math.random() > 0.1) {
                resolve();
                return { ...f, progress: 100, status: UploadStatus.Success };
              } else {
                reject(new Error("فشل التحميل"));
                return { ...f, progress: 100, status: UploadStatus.Error, error: "فشل التحميل" };
              }
            }
            return { ...f, progress: newProgress };
          }
          return f;
        }));
      }, 200);
    });
  };

  const handleUpload = async () => {
    setIsUploading(true);
    setFiles(prev => prev.map(f => f.status === UploadStatus.Waiting ? { ...f, status: UploadStatus.Uploading } : f));
    
    const uploadPromises = files
      .filter(f => f.status === UploadStatus.Waiting)
      .map(f => simulateUpload(f.id));

    await Promise.allSettled(uploadPromises);
    setIsUploading(false);
  };
  
  useEffect(() => {
    // Cleanup object URLs on unmount
    return () => {
      files.forEach(file => URL.revokeObjectURL(file.previewUrl));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleReset = () => {
    setFiles([]);
  };

  const waitingFilesCount = files.filter(f => f.status === UploadStatus.Waiting).length;
  const successFilesCount = files.filter(f => f.status === UploadStatus.Success).length;
  const hasFiles = files.length > 0;
  const isFull = files.length >= MAX_FILES;
  const allUploadsSucceeded = hasFiles && !isUploading && files.every(f => f.status === UploadStatus.Success);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
      {allUploadsSucceeded ? (
        <div className="text-center py-8 flex flex-col items-center">
            <SuccessIllustrationIcon className="w-24 h-24" />
            <h2 className="mt-4 text-2xl font-bold text-green-600">اكتمل التحميل بنجاح!</h2>
            <p className="mt-2 text-slate-500">
                {`تم تحميل ${files.length} ${files.length > 2 ? 'صور' : 'صورة'} بنجاح.`}
            </p>
            <button
                onClick={handleReset}
                className="mt-6 inline-block cursor-pointer rounded-md bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 transition-transform hover:scale-105"
            >
                تحميل المزيد من الصور
            </button>
        </div>
      ) : (
        <>
            <div 
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors duration-300 ${
                    isFull 
                    ? 'bg-slate-100 border-slate-200 cursor-not-allowed' 
                    : isDragging 
                    ? 'border-indigo-500 bg-indigo-50' 
                    : 'border-slate-300 bg-slate-50'
                }`}
                onDragEnter={!isFull ? handleDragEnter : undefined}
                onDragLeave={!isFull ? handleDragLeave : undefined}
                onDragOver={!isFull ? handleDragOver : undefined}
                onDrop={!isFull ? handleDrop : undefined}
            >
                <UploadCloudIcon className={`mx-auto h-12 w-12 ${isFull ? 'text-slate-300' : 'text-slate-400'}`} />
                {isFull ? (
                    <>
                        <p className="mt-4 text-lg font-semibold text-slate-500">تم الوصول إلى الحد الأقصى للصور</p>
                        <p className="mt-1 text-sm text-slate-400">يمكنك تحميل {MAX_FILES} صور كحد أقصى.</p>
                    </>
                ) : (
                    <>
                        <p className="mt-4 text-lg font-semibold text-slate-700">اسحب وأفلت الصور هنا</p>
                        <p className="mt-1 text-sm text-slate-500">أو</p>
                        <label htmlFor="file-upload" className="mt-4 inline-block cursor-pointer rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 transition-transform hover:scale-105">
                        <span>اختر الملفات</span>
                        <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple accept="image/*" onChange={handleFileChange} disabled={isFull} />
                        </label>
                        <p className="mt-3 text-xs text-slate-400">PNG, JPG, GIF حتى 10 ميجابايت</p>
                    </>
                )}
            </div>

            {hasFiles && (
                <div className="mt-8">
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
                        <h2 className="text-xl font-bold text-slate-800">
                            {successFilesCount > 0 ? `${successFilesCount} / ${files.length} صور مكتملة` : `ملفات جاهزة للتحميل (${files.length}/${MAX_FILES})`}
                        </h2>
                        {waitingFilesCount > 0 && (
                            <button
                                onClick={handleUpload}
                                disabled={isUploading}
                                className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-md bg-green-600 px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-green-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                            >
                                {isUploading ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        <span>جاري التحميل...</span>
                                    </>
                                ) : (
                                    <>
                                        <CheckCircleIcon className="w-5 h-5" />
                                        <span>تحميل {waitingFilesCount} ملف</span>
                                    </>
                                )}
                            </button>
                        )}
                    </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {files.map(file => (
                    <ImagePreviewCard 
                        key={file.id} 
                        file={file} 
                        onRemove={() => removeFile(file.id)}
                    />
                    ))}
                </div>
                </div>
            )}
        </>
      )}
    </div>
  );
};

export default ImageUploader;


import React from 'react';
import { ManagedFile, UploadStatus } from '../types';
import { TrashIcon, CheckCircleSolidIcon, ExclamationCircleSolidIcon, ClockIcon } from './Icons';

interface ImagePreviewCardProps {
  file: ManagedFile;
  onRemove: () => void;
}

const formatBytes = (bytes: number, decimals = 2) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

const StatusIndicator: React.FC<{ status: UploadStatus }> = ({ status }) => {
    switch (status) {
        case UploadStatus.Success:
            return <div className="flex items-center gap-1 text-green-600"><CheckCircleSolidIcon className="w-4 h-4" /><span>اكتمل</span></div>;
        case UploadStatus.Error:
            return <div className="flex items-center gap-1 text-red-600"><ExclamationCircleSolidIcon className="w-4 h-4" /><span>خطأ</span></div>;
        case UploadStatus.Uploading:
            return <div className="flex items-center gap-1 text-blue-600"><ClockIcon className="w-4 h-4 animate-spin" /><span>جاري الرفع</span></div>;
        default:
            return <div className="flex items-center gap-1 text-slate-500"><ClockIcon className="w-4 h-4" /><span>في الانتظار</span></div>;
    }
};

const ImagePreviewCard: React.FC<ImagePreviewCardProps> = ({ file, onRemove }) => {
  const isActionable = file.status === UploadStatus.Waiting || file.status === UploadStatus.Error;

  return (
    <div className="relative group flex flex-col bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md">
      <div className="relative">
        <img src={file.previewUrl} alt={file.file.name} className="w-full h-40 object-cover" />
        {isActionable && (
          <button 
            onClick={onRemove}
            className="absolute top-2 right-2 bg-black/50 p-1.5 rounded-full text-white hover:bg-red-600 transition-all scale-0 group-hover:scale-100"
            aria-label="Remove file"
          >
            <TrashIcon className="w-5 h-5" />
          </button>
        )}
      </div>

      <div className="flex-1 p-3 flex flex-col justify-between">
        <div>
            <p className="text-sm font-semibold text-slate-800 truncate" title={file.file.name}>{file.file.name}</p>
            <div className="flex justify-between items-center text-xs text-slate-500 mt-1">
                <span>{formatBytes(file.file.size)}</span>
                <StatusIndicator status={file.status} />
            </div>
        </div>

        {file.status === UploadStatus.Error && file.error && (
            <p className="text-xs text-red-500 mt-2">{file.error}</p>
        )}
      </div>

      {file.status === UploadStatus.Uploading && (
        <div className="w-full bg-slate-200 h-1">
          <div className="bg-indigo-600 h-1" style={{ width: `${file.progress}%`, transition: 'width 0.2s ease-in-out' }}></div>
        </div>
      )}
      {file.status === UploadStatus.Success && (
        <div className="w-full bg-green-500 h-1"></div>
      )}
      {file.status === UploadStatus.Error && (
        <div className="w-full bg-red-500 h-1"></div>
      )}
    </div>
  );
};

export default ImagePreviewCard;

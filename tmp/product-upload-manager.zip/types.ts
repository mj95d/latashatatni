
export enum UploadStatus {
  Waiting = 'waiting',
  Uploading = 'uploading',
  Success = 'success',
  Error = 'error',
}

export interface ManagedFile {
  id: string;
  file: File;
  previewUrl: string;
  status: UploadStatus;
  progress: number;
  error?: string;
}

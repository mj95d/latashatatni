
import React from 'react';
import ImageUploader from './components/ImageUploader';
import { GithubIcon } from './components/Icons';

function App() {
  return (
    <div className="bg-slate-50 min-h-screen text-slate-800">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-900">مدير تحميل صور المنتج</h1>
          <a href="https://github.com/your-repo" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-slate-800 transition-colors">
            <GithubIcon className="w-7 h-7" />
          </a>
        </div>
      </header>
      <main className="container mx-auto p-4 md:p-8">
        <ImageUploader />
      </main>
      <footer className="text-center py-4 text-sm text-slate-500">
        <p>تصميم وتطوير بواسطة مهندس الواجهة الأمامية الخبير</p>
      </footer>
    </div>
  );
}

export default App;
